#include <stdio.h>
#include <ctype.h>
#include <string>
#include <BNO055.h>
#include <LPD8806.h>
#include <hcsr04.h>

BNO055 bno(p28, p27); // initialize gyro
LPD8806 strip(32); // initialize LED strip
Serial pc(USBTX, USBRX);
HCSR04 ultra(p25, p6); 

enum State {
    notStarted,
    holding,
    startRolling,
    rolling,
    stopped,
    walkBy
};

// increased pressure applied = increased V read
bool sensePressure();
AnalogIn thickSensor(p15); //range of 0.78 to 0.96
AnalogIn thinSensor(p20); //range of 0.86 to 0.93
AnalogIn otherSensor(p18); //range of 0.87 to 0.94

const int pressureArrayLength = 10;
const int gyroArrayLength = 10;
const int ultraArrayLength = 3;
float thinAvg[pressureArrayLength] = {5, 5, 5, 5, 5, 5, 5, 5, 5, 5};;
float thickAvg[pressureArrayLength] = {5, 5, 5, 5, 5, 5, 5, 5, 5, 5};;
float otherAvg[pressureArrayLength] = {5, 5, 5, 5, 5, 5, 5, 5, 5, 5};;
float gyroAvg[gyroArrayLength];
float ultraAvg[ultraArrayLength];
int pressureIndex;
int gyroIndex;
int ultraIndex;
float gyroThresh = 5;
float thickThresh;
float thinThresh;
float otherThresh;
float delta = 0.07;
float recentTime;
float timeHold = 15;
State s = notStarted;
int wrong = 0;
float lastGyroTime = 0;
bool pressure = false;
float initialTime;
bool isDone = false;

// green = start rolling
// blue = good
// red = doing something wrong

float average(float array[], float length);

// detect speed
float senseGyro(); 
bool senseUltra();

// detect angle
float senseAngle();

Timer t; // initialize time variable

int main() {
    t.start();
    recentTime = t.read();
    initialTime = t.read();
    bno.set_anglerate_units(DEG_PER_SEC);
    bno.set_angle_units(DEGREES);
    bno.set_orientation(WINDOWS);
    bno.setmode(OPERATION_MODE_COMPASS);
    strip.begin();
    pressureIndex=0;
    gyroIndex = 0;
    
    // reset all LED colors
    for (int i = 0; i < 32; i++) {
         strip.setPixelColor(i, 0, 0, 0);
         strip.show(); 
    } 
    
 // shine bright white LED for 2 seconds at start of session
    for (int i = 0; i < 32; i++) {
         strip.setPixelColor(i, 255, 0, 0);
         strip.show(); 
    }
    wait_ms(2000);
    for (int i = 0; i < 32; i++) {
         strip.setPixelColor(i, 0, 0, 0);
         strip.show(); 
    }
    thickThresh = ((thickSensor.read() + thickSensor.read() + thickSensor.read() + thickSensor.read() + thickSensor.read() ) / 5.0) - delta;
    thinThresh = ((thinSensor.read() + thinSensor.read() + thinSensor.read() + thinSensor.read() + thinSensor.read() ) / 5.0) - delta;
    otherThresh = ((otherSensor.read() + otherSensor.read() + otherSensor.read() + otherSensor.read() + otherSensor.read() ) / 5.0) - delta;
    
    while(1) {
        pressure = sensePressure();
        float speed = senseGyro();
        
        //routine
        switch(s) {
            // white
            case notStarted:
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 255, 255, 255);
                }  
                strip.show();
                // printf("not started \n");
                if (pressure) {
                    s = holding;
                    recentTime = t.read();
                } else if (senseUltra()) {
                    s = walkBy;
                    recentTime = t.read();
                } else {
                    s = notStarted;    
                }
                break;
                
                // blue
            case holding:
                if (t.read() - recentTime >= timeHold && pressure) {
                    s = startRolling;
                }  else if (pressure) {
                     for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 0, 0, 255);
                    }  
                    strip.show();
                } else if (!pressure) {
                    wrong++;
                }
                break;
                // green
            case startRolling:
                for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 0, 0, 0);
                } 
                strip.show();
                wait_ms(200); 
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 0, 255, 0);
                }  
                strip.show();
                
                // printf ("start rolling \n");
                recentTime = t.read();
                if (pressure && (speed >= gyroThresh)) {
                    s = rolling;
                } else if (!pressure) {
                    wrong++;
                }
                break;
                // red
            case rolling:
                if (t.read() - recentTime >= timeHold) {
                    s = stopped;
                } else if (pressure && (speed >= gyroThresh)) {
//                    for (int i = 0; i < 32; i++) {
//                        strip.setPixelColor(i, 0, 0, 0);
//                    } 
//                    strip.show();
//                    wait_ms(200); 
                    for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 153, 50, 204);
                    }  
                    strip.show();
                    // printf("rolling \n");
                 } else {
                    wrong++;
                }
                break;
                
            case stopped:
                if (!isDone) {
                    for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 0, 0, 0);
                        strip.show();
                    }  
                    wait_ms(2000);
                    isDone = true;
                }
            if (wrong / (t.read() - initialTime) > 0.75) {
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 255, 0, 0);
                    strip.show();
                }  
            } else if (wrong / (t.read() - initialTime) > 0.5) {
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 0, 0, 255);
                    strip.show();
                }  
            } else {
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 0, 255, 0);
                    strip.show();
                }  
            }
                // printf ("stopped \n");
                break;
                
            case walkBy:
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 0, 255, 255);
                } 
                strip.show();
                wait_ms(100);
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 0, 0, 0);
                } 
                strip.show();
                if (t.read() - recentTime >= 5) {
                    s = notStarted;
                }
                break;
            default:
               for(int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 5*i, 5*i, 5*i);
                }  
                strip.show();
               // printf("default");
        }
    }
}

float average (float array[], float length){
    float ret = 0;
    int j;
    for (j = 0; j < length; j++){
        ret += array[j];
    }
    return ret / length;
}


bool sensePressure() {
    thickAvg[pressureIndex] = thickSensor.read(); // ranges from 0.83 to 0.93
    thinAvg[pressureIndex] = thinSensor.read(); //0.35 to 0.48
    otherAvg[pressureIndex] = otherSensor.read(); //0.35 to 0.48
    float x = average (thickAvg, pressureArrayLength);
    float y = average (thinAvg, pressureArrayLength);
    float z = average (otherAvg, pressureArrayLength);
    pressureIndex++;
    if (pressureIndex >= pressureArrayLength) {
        pressureIndex = 0;
    }
    // if (x <= thickThresh || y <= thinThresh || z <= otherThresh) {
    if (x <= thickThresh) {
        return true;
    }
    return false;
}

float senseGyro() {
//    bno.get_angles();
//    float prev_avg = average (gyroAvg, gyroArrayLength);
//    gyroAvg[gyroIndex] = bno.euler.pitch;
//    float new_avg = average (gyroAvg, gyroArrayLength);
//    gyroIndex++;
//    if (gyroIndex >= gyroArrayLength){
//        gyroIndex = 0;
//    }
//    return abs(new_avg - prev_avg);  
    bno.get_angles();
    float prev_avg = average (gyroAvg, gyroArrayLength);
    gyroAvg[gyroIndex] = bno.euler.pitch;
    float new_avg = average (gyroAvg, gyroArrayLength);
    float deltaAngle = abs(new_avg - prev_avg);
    float deltaTime = t.read() - lastGyroTime;
    lastGyroTime = t.read();
    gyroIndex++;
    if (gyroIndex >= gyroArrayLength){
        gyroIndex = 0;
    }
    return deltaAngle / deltaTime;
}

bool senseUltra() {
    ultra.start();
    ultraAvg[ultraIndex] = ultra.get_dist_cm();
    ultraIndex++;
    if (ultraIndex >= ultraArrayLength) {
        ultraIndex = 0;
    }
    if (average(ultraAvg, ultraArrayLength) < -5) {
        return true;
    }
    return false;
}

float senseAngle() {
    bno.get_angles();
    float angle = bno.euler.pitch;
    return angle;
}