#include <stdio.h>
#include <ctype.h>
#include <string>
#include <BNO055.h>
#include <LPD8806.h>

BNO055 bno(p28, p27); // initialize gyro
LPD8806 strip(32); // initialize LED strip
Serial pc(USBTX, USBRX);

enum State {
    notStarted,
    holding,
    startRolling,
    rolling,
    stopped
};

// detect pressure
void sensePressure();
AnalogIn thickSensor(p15); //range of 0.45 to 0.48
AnalogIn thinSensor(p20); //range of 0.45 to 0.48
const int pressureArrayLength = 5;
const int gyroArrayLength = 10;
float thinAvg[pressureArrayLength];
float thickAvg[pressureArrayLength];
float gyroAvg[gyroArrayLength];
int pressureIndex;
int gyroIndex;
float gyroThresh = 55;
float thickThresh; // = .6;
float thinThresh; // = .45;
float delta = 0.015;
float recentTime;
float timeHold = 5;
State s = notStarted;

// green = start rolling
// blue = good
// red = doing something wrong

float average(float array[], int length);
// detect speed
float senseGyro(); 

Timer t; // initialize time variable


int main() {
    t.start();
    recentTime = t.read();
    bno.set_anglerate_units(DEG_PER_SEC);
    bno.set_angle_units(DEGREES);
    bno.set_orientation(WINDOWS);
    bno.setmode(OPERATION_MODE_GYRONLY);
    strip.begin();
    pressureIndex=0;
    gyroIndex = 0;
    
    // reset all LED colors
    for (int i = 0; i < 32; i++) {
         strip.setPixelColor(i, 0, 0, 0);
         strip.show(); 
    } 
    
 //    shine bright white LED for 3 seconds at start of session
    for (int i = 0; i < 32; i++) {
         strip.setPixelColor(i, 255, 255, 255);
         strip.show(); 
    }
    wait_ms(1000);
    for (int i = 0; i < 32; i++) {
         strip.setPixelColor(i, 0, 0, 0);
         strip.show(); 
    } 
    thickThresh = ((thickSensor.read() + thickSensor.read() + thickSensor.read() + thickSensor.read() + thickSensor.read() ) / 5) - delta;
    thinThresh = ((thinSensor.read() + thinSensor.read() + thinSensor.read() + thinSensor.read() + thinSensor.read() ) / 5) - delta;
    
    while(1) {
        wait_ms(200);
        sensePressure();
        float speed = senseGyro();
        float x = average (thickAvg, pressureArrayLength);
        float y = average (thinAvg, pressureArrayLength);
        
        //routine
        switch(s) {
            // white
            case notStarted:
            
            
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 255, 255, 255);
                }  
                strip.show();
                // printf("not started \n");
                if (x <= thickThresh || y <= thinThresh) {
                    s = holding;
                    recentTime = t.read();
                }
                break;
                
                // blue
            case holding:
                if (t.read() - recentTime >= timeHold) {
                    s = startRolling;
                } else if (x <= thickThresh || y <= thinThresh) {
                    for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 0, 0, 0);
                    } 
                    strip.show();
                    wait_ms(200); 
                    for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 0, 0, 255);
                    }  
                    strip.show();
                    // printf("holding \n");
                } else {
                    s = notStarted;
                }
                break;
                // green
            case startRolling:
                for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 0, 0, 0);
                } 
                strip.show();
                wait_ms(200); 
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 0, 255, 0);
                }  
                strip.show();
                // printf ("start rolling \n");
                recentTime = t.read();
                if ((x <= thickThresh || y <= thinThresh) && speed >= gyroThresh) {
                    s = rolling;
                } else if ((x > thickThresh && y > thinThresh)) {
                    s = notStarted;
                }
                break;
                // red
            case rolling:
                if (t.read() - recentTime >= timeHold) {
                    s = stopped;
                } else if ((x <= thickThresh || y <= thinThresh) && speed >= gyroThresh) {
                    for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 0, 0, 0);
                    } 
                    strip.show();
                    wait_ms(200); 
                    for (int i = 0; i < 32; i++) {
                        strip.setPixelColor(i, 255, 0, 0);
                    }  
                    strip.show();
                    // printf("rolling \n");
                } else {
                    s = notStarted;
                }
                break;
            case stopped: 
                for (int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 255, 0, 255);
                    strip.show();
                }  
                // printf ("stopped \n");
                break;
            default:
               for(int i = 0; i < 32; i++) {
                    strip.setPixelColor(i, 5*i, 5*i, 5*i);
                }  
                strip.show();
               // printf("default");
        }
    }
}

        
        /*if (speed >= gyroThresh && x >= thickThresh && y >= thinThresh) {
            strip.setPixelColor(11, 0, 255, 0);
            //strip.setPixelColor(1, 255, 255, 255);
//            strip.setPixelColor(11, 0, 0, 0);
            strip.show();   
        } else {
            strip.setPixelColor(11, 0, 0, 0);
            //strip.setPixelColor(1, 0, 0, 0);
//            strip.setPixelColor(11, 0, 0, 0);
            strip.show();
        }
        if (x <= thickThresh) {
            strip.setPixelColor(16, 0, 0, 255);
            strip.show();  
        } else {
            strip.setPixelColor(16, 255, 0, 0);
            strip.show();
        } 
        if (y <= thinThresh) {
            strip.setPixelColor(21, 0, 0, 255);
            // strip.setPixelColor(31, 255, 0, 0);
            strip.show();  
        } else {
            strip.setPixelColor(21, 255, 0, 0);
            // strip.setPixelColor(15, 0, 0, 0);
            strip.show();
        } 
        if (speed >= gyroThresh + 100) {
            strip.setPixelColor(26, 255, 255, 0);
            strip.show();  
        } else if (speed >= gyroThresh) {
            strip.setPixelColor(26, 0, 255, 0);
            strip.show(); 
        } else {
            strip.setPixelColor(26, 0, 0, 255);
            strip.show(); 
        }*/
//        
//        // start rolling after 3 seconds
//        if (t.read() >= 3) {
//            for (int i = 0; i < 32; i++) {
//                strip.setPixelColor(i, 255, 0, 0);
//                strip.show(); 
//                wait_ms(300);
//            }  
//            for (int i = 0; i < 32; i++) {
//                strip.setPixelColor(i, 0, 255, 0);
//                strip.show(); 
//                wait_ms(300);
//            } 
//            for (int i = 0; i < 32; i++) {
//                strip.setPixelColor(i, 0, 0, 255);
//                strip.show(); 
//                wait_ms(300);
//            }  
//        }
//    }
// }



float average (float array[], int length){
    float ret = 0;
    int j;
    for (j = 0; j < length; j++){
        ret += array[j];
    }
    return ret / (length);
}


void sensePressure() {
    thickAvg[pressureIndex] = thickSensor.read(); // ranges from 0.83 to 0.93
    thinAvg[pressureIndex] = thinSensor.read(); //0.35 to 0.48
    //float x = average (thickAvg, pressureArrayLength);
    //float y = average (thinAvg, pressureArrayLength);
    pressureIndex++;
    if (pressureIndex >= pressureArrayLength) {
        pressureIndex = 0;
    }
//    if (x >= .9 && y >= 0.45) {
//        strip.setPixelColor(11, 0, 255, 0);
//        strip.setPixelColor(21, 0, 0, 0);
//        strip.show();   
//    } else {
//        strip.setPixelColor(21, 255, 0, 0);
//        strip.setPixelColor(11, 0, 0, 0);
//        strip.show();  
//    }     
}

float senseGyro() {
    bno.get_gyro();
    gyroAvg[gyroIndex] = abs(bno.gyro.x);
    float x = average (gyroAvg, gyroArrayLength);
    gyroIndex++;
    if (gyroIndex >= gyroArrayLength){
        gyroIndex = 0;
    }
    // pc.printf("%f\n", x);
//    if (x > 200 &&  x < 500) {
//        strip.setPixelColor(0, 255, 0, 0);
//        strip.show();
//    } else if (x >= 500 && x < 750) {
//        strip.setPixelColor(10, 255, 0, 0);
//        strip.show();
//    } else if (x >= 1000) {
//        strip.setPixelColor(20, 255, 0, 0);
//        strip.show();   
//    } else {
//        strip.setPixelColor(30, 255, 0, 0);
//        strip.show();
//    }  
    return x;  
}