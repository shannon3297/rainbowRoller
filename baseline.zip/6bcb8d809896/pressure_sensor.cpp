//#include "mbed.h"
//
//// Serial port for showing RX data.
//Serial pc(USBTX, USBRX);
//
//
//DigitalOut greenLed(p20);
//DigitalOut redLed(p19);
//AnalogIn pressureSensor(p12);
//// AnalogIn accel(p11);
//float pressure;
//
//
//void sensePressure() {
//    while(1) {
////        
//        greenLed = 1;
//        wait(0.2);
//        greenLed = 0;
//        wait(0.2);
////        
//      pressure = pressureSensor.read();
//      pc.printf("%f", pressure);
//        //pc.printf("hello");
////        // INSERT SOME THRESHOLD HERE
////        if (pressure > 0) {
////            greenLed = 1;
////        } else {
////            redLed = 1;
////        }
//        //if (accel.readX())
//        /*
//        greenLed = 1;
//        redLed = 0;
//        wait(0.2);
//        greenLed = 0;
//        redLed = 1;
//        wait(0.2);
//        */
//   }
//}